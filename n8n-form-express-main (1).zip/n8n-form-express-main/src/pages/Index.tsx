import { N8NForm } from "@/components/N8NForm";

const Index = () => {
  return <N8NForm />;
};

export default Index;
