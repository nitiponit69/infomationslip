import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { format } from "date-fns";
import { CalendarIcon, Loader2, Save, Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Checkbox } from "@/components/ui/checkbox";

const formSchema = z.object({
  recorder: z.string().email("กรุณากรอกอีเมลที่ถูกต้อง").min(1, "กรุณากรอกข้อมูล"),
  requestType: z.string().min(1, "กรุณาเลือกประเภทใบขอ"),
  workType: z.string().min(1, "กรุณาเลือกลักษณะงาน"),
  lastWorkDay: z.date({ required_error: "กรุณาเลือกวันที่" }),
  effectiveDate: z.date({ required_error: "กรุณาเลือกวันที่" }),
  requestDate: z.date({ required_error: "กรุณาเลือกวันที่" }),
  siteCode: z.string().min(1, "กรุณากรอกรหัสไซต์"),
  requestNumber: z.string().min(1, "กรุณากรอกเลขที่ใบขอ"),
  department: z.string().min(1, "กรุณากรอกชื่อหน่วยงาน"),
  province: z.string().min(1, "กรุณากรอกจังหวัด"),
  ocCode: z.string().optional(),
  reason: z.string().optional(),
  employeeName: z.string().optional(),
  employeePhone: z.string().optional(),
  reusable: z.string().min(1, "กรุณาเลือกตัวเลือก"),
  workLocation: z.string().optional(),
  carInfo: z.string().optional(),
  quantity: z.string().optional(),
  note: z.string().optional(),
  salary: z.string().optional(),
  deposit: z.string().optional(),
  deductionList: z.string().optional(),
  documents: z.string().optional(),
  erpRequest: z.string().min(1, "กรุณาเลือกตัวเลือก"),
  irecruitRequest: z.string().optional(),
  oplOfficer: z.string().min(1, "กรุณาเลือกจนท.OPL"),
  emailRecipients: z.array(z.string()).min(1, "กรุณาเลือกอีเมลอย่างน้อย 1 อีเมล"),
  cc: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

// N8N Webhook URL - ตั้งค่าที่นี่
const N8N_WEBHOOK_URL = "https://n8n.siamrajathanee.dev/webhook/1a18bd6b-b739-440c-91cb-fba524eb5269";

export function N8NForm() {
  const [isLoading, setIsLoading] = useState(false);
  const [fileAttachment, setFileAttachment] = useState<File | null>(null);
  const [openComboboxes, setOpenComboboxes] = useState<Record<string, boolean>>({});

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      recorder: "",
      requestType: "",
      workType: "",
      siteCode: "",
      requestNumber: "",
      department: "",
      province: "",
      ocCode: "",
      reason: "",
      employeeName: "",
      employeePhone: "",
      reusable: "",
      workLocation: "",
      carInfo: "",
      quantity: "",
      note: "",
      salary: "",
      deposit: "",
      deductionList: "",
      documents: "",
      erpRequest: "",
      irecruitRequest: "",
      oplOfficer: "",
      emailRecipients: [],
      cc: "",
    },
  });

  const onSubmit = async (data: FormData) => {
    setIsLoading(true);

    try {
      const formData = new FormData();
      
      // Add all form fields
      Object.entries(data).forEach(([key, value]) => {
        if (value instanceof Date) {
          formData.append(key, format(value, "yyyy-MM-dd"));
        } else if (Array.isArray(value)) {
          formData.append(key, value.join(", "));
        } else {
          formData.append(key, value?.toString() || "");
        }
      });

      // Add file attachment if exists
      if (fileAttachment) {
        formData.append("fileAttach", fileAttachment);
      }

      const response = await fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        toast({
          title: "ส่งสำเร็จ",
          description: "บันทึกข้อมูลเรียบร้อยแล้ว",
        });
        form.reset();
        setFileAttachment(null);
      } else {
        throw new Error("Failed to send data");
      }
    } catch (error) {
      console.error("Error:", error);
      toast({
        title: "ส่งไม่สำเร็จ",
        description: "ไม่สามารถบันทึกข้อมูลได้ กรุณาลองใหม่อีกครั้ง",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const recorderOptions = ["user1@example.com", "user2@example.com", "user3@example.com"];
  const requestTypeOptions = ["ประเภท 1", "ประเภท 2", "ประเภท 3"];
  const workTypeOptions = ["งาน 1", "งาน 2", "งาน 3"];
  const oplOfficerOptions = ["เจ้าหน้าที่ 1", "เจ้าหน้าที่ 2", "เจ้าหน้าที่ 3"];
  const emailOptions = [
    "opl@siamraj.com",
    "rm@siamraj.com",
    "pr@siamraj.com",
    "sq@siamraj.com",
    "lao@siamraj.com",
    "mk@siamraj.com",
    "bld@siamraj.com",
    "nittipon.b@siamraj.com",
  ];

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-card rounded-2xl shadow-lg p-6 md:p-8 border border-border">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">
              แบบฟอร์มใบขอ
            </h1>
            <p className="text-muted-foreground">
              กรอกข้อมูลเพื่อส่งไปยัง N8N
            </p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="recorder"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>ผู้บันทึกใบขอ</FormLabel>
                      <Popover open={openComboboxes['recorder']} onOpenChange={(open) => setOpenComboboxes({...openComboboxes, recorder: open})}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                "w-full justify-between",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value || "เลือกหรือพิมพ์อีเมล"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 bg-popover z-50">
                          <Command>
                            <CommandInput 
                              placeholder="ค้นหาหรือพิมพ์อีเมล..." 
                              value={field.value}
                              onValueChange={field.onChange}
                            />
                            <CommandList>
                              <CommandEmpty>ไม่พบข้อมูล</CommandEmpty>
                              <CommandGroup>
                                {recorderOptions.map((email) => (
                                  <CommandItem
                                    key={email}
                                    value={email}
                                    onSelect={() => {
                                      field.onChange(email);
                                      setOpenComboboxes({...openComboboxes, recorder: false});
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        field.value === email ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {email}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="requestType"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>ประเภทใบขอ</FormLabel>
                      <Popover open={openComboboxes['requestType']} onOpenChange={(open) => setOpenComboboxes({...openComboboxes, requestType: open})}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                "w-full justify-between",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value || "เลือกหรือพิมพ์ประเภท"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 bg-popover z-50">
                          <Command>
                            <CommandInput 
                              placeholder="ค้นหาหรือพิมพ์ประเภท..." 
                              value={field.value}
                              onValueChange={field.onChange}
                            />
                            <CommandList>
                              <CommandEmpty>ไม่พบข้อมูล</CommandEmpty>
                              <CommandGroup>
                                {requestTypeOptions.map((type) => (
                                  <CommandItem
                                    key={type}
                                    value={type}
                                    onSelect={() => {
                                      field.onChange(type);
                                      setOpenComboboxes({...openComboboxes, requestType: false});
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        field.value === type ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {type}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="workType"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>ลักษณะงาน</FormLabel>
                      <Popover open={openComboboxes['workType']} onOpenChange={(open) => setOpenComboboxes({...openComboboxes, workType: open})}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                "w-full justify-between",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value || "เลือกหรือพิมพ์ลักษณะงาน"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 bg-popover z-50">
                          <Command>
                            <CommandInput 
                              placeholder="ค้นหาหรือพิมพ์ลักษณะงาน..." 
                              value={field.value}
                              onValueChange={field.onChange}
                            />
                            <CommandList>
                              <CommandEmpty>ไม่พบข้อมูล</CommandEmpty>
                              <CommandGroup>
                                {workTypeOptions.map((work) => (
                                  <CommandItem
                                    key={work}
                                    value={work}
                                    onSelect={() => {
                                      field.onChange(work);
                                      setOpenComboboxes({...openComboboxes, workType: false});
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        field.value === work ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {work}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lastWorkDay"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>ทำงานวันสุดท้ายวันที่</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy")
                              ) : (
                                <span>เลือกวันที่</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 bg-popover z-50" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="effectiveDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>มีผลวันที่</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy")
                              ) : (
                                <span>เลือกวันที่</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 bg-popover z-50" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="requestDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>วันที่ต้องการ</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "dd/MM/yyyy")
                              ) : (
                                <span>เลือกวันที่</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0 bg-popover z-50" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="siteCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>รหัสไซต์</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกรหัสไซต์" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="requestNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>เลขที่ใบขอ</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกเลขที่ใบขอ" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="department"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ชื่อหน่วยงาน</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกชื่อหน่วยงาน" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="province"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>จังหวัด</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกจังหวัด" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="ocCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>OC Code</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอก OC Code" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="reason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>สาเหตุ</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกสาเหตุ" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="employeeName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>รายชื่อพนักงานลาออก</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกรายชื่อ" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="employeePhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>เบอร์โทรพนักงาน</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกเบอร์โทร" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="reusable"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>ใช้งานต่อได้หรือไม่</FormLabel>
                      <Popover open={openComboboxes['reusable']} onOpenChange={(open) => setOpenComboboxes({...openComboboxes, reusable: open})}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                "w-full justify-between",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value || "เลือกหรือพิมพ์"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 bg-popover z-50">
                          <Command>
                            <CommandInput 
                              placeholder="พิมพ์..." 
                              value={field.value}
                              onValueChange={field.onChange}
                            />
                            <CommandList>
                              <CommandEmpty>ไม่พบข้อมูล</CommandEmpty>
                              <CommandGroup>
                                {["ได้", "ไม่ได้"].map((option) => (
                                  <CommandItem
                                    key={option}
                                    value={option}
                                    onSelect={() => {
                                      field.onChange(option);
                                      setOpenComboboxes({...openComboboxes, reusable: false});
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        field.value === option ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {option}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="carInfo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>รุ่นรถ / ทะเบียนรถ</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกข้อมูลรถ" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="quantity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>จำนวนที่ต้องการ</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกจำนวน" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="salary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>อัตราเงินเดือนที่ต้องการ</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกเงินเดือน" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="deposit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>เงินประกันการทำงาน</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกเงินประกัน" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="deductionList"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>รายการหัก-ไม่หัก</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกรายการ" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="documents"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>เอกสารประกอบ</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกเอกสาร" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="erpRequest"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>เปิดใบขอ (ERP)</FormLabel>
                      <Popover open={openComboboxes['erpRequest']} onOpenChange={(open) => setOpenComboboxes({...openComboboxes, erpRequest: open})}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                "w-full justify-between",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value || "เลือกหรือพิมพ์"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 bg-popover z-50">
                          <Command>
                            <CommandInput 
                              placeholder="พิมพ์..." 
                              value={field.value}
                              onValueChange={field.onChange}
                            />
                            <CommandList>
                              <CommandEmpty>ไม่พบข้อมูล</CommandEmpty>
                              <CommandGroup>
                                {["ใช้", "ไม่ใช้"].map((option) => (
                                  <CommandItem
                                    key={option}
                                    value={option}
                                    onSelect={() => {
                                      field.onChange(option);
                                      setOpenComboboxes({...openComboboxes, erpRequest: false});
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        field.value === option ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {option}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="irecruitRequest"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>เปิดใบขอ (iRecruit)</FormLabel>
                      <FormControl>
                        <Input placeholder="กรอกข้อมูล" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="oplOfficer"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>จนท.OPL</FormLabel>
                      <Popover open={openComboboxes['oplOfficer']} onOpenChange={(open) => setOpenComboboxes({...openComboboxes, oplOfficer: open})}>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              role="combobox"
                              className={cn(
                                "w-full justify-between",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value || "เลือกหรือพิมพ์เจ้าหน้าที่"}
                              <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 bg-popover z-50">
                          <Command>
                            <CommandInput 
                              placeholder="ค้นหาหรือพิมพ์..." 
                              value={field.value}
                              onValueChange={field.onChange}
                            />
                            <CommandList>
                              <CommandEmpty>ไม่พบข้อมูล</CommandEmpty>
                              <CommandGroup>
                                {oplOfficerOptions.map((officer) => (
                                  <CommandItem
                                    key={officer}
                                    value={officer}
                                    onSelect={() => {
                                      field.onChange(officer);
                                      setOpenComboboxes({...openComboboxes, oplOfficer: false});
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        field.value === officer ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {officer}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="emailRecipients"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ระบุอีเมลที่ต้องการจัดส่ง (เลือกได้หลายอีเมล)</FormLabel>
                      <div className="space-y-2">
                        {emailOptions.map((email) => (
                          <div key={email} className="flex items-center space-x-2">
                            <Checkbox
                              checked={field.value?.includes(email)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), email]
                                  : (field.value || []).filter((val) => val !== email);
                                field.onChange(updatedValue);
                              }}
                            />
                            <label className="text-sm font-normal cursor-pointer">
                              {email}
                            </label>
                          </div>
                        ))}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="workLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>สถานที่รับนาย / เริ่มงาน</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="กรอกสถานที่"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="note"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>หมายเหตุ</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="กรอกหมายเหตุ"
                        className="resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="cc"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CC (สำเนาถึง)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="กรอกอีเมล CC คั่นด้วย ,"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div>
                <label className="block text-sm font-medium mb-2 text-foreground">
                  แนบไฟล์เอกสาร
                </label>
                <Input
                  type="file"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) setFileAttachment(file);
                  }}
                  className="w-full"
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                size="lg"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    กำลังบันทึกข้อมูล...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    กดบันทึกข้อมูล
                  </>
                )}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
